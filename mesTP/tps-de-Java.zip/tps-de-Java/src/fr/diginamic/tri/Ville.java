package fr.diginamic.tri;

import java.util.ArrayList;
import java.util.List;

public class Ville implements Comparable<Ville> {

	
	String nomVille;
	int nbHabitants;
	
	
	public Ville(String nomVille, int nbHabitants) {
		super();
		this.nomVille = nomVille;
		this.nbHabitants = nbHabitants;
		
	}
	@Override
	public int compareTo(Ville autre) {
		if(this.getNomVille.compareTo(autre.getNomVille()){
			return 1;
		}else if(this.getNomVille.compareTo(autre.getNomVille()){
	return -1;{
	else{
		return 0;
	}
	}


	public String getNomVille() {
		return nomVille;
	}


	public void setNomVille(String nomVille) {
		this.nomVille = nomVille;
	}


	public int getNbHabitants() {
		return nbHabitants;
	}


	public void setNbHabitants(int nbHabitants) {
		this.nbHabitants = nbHabitants;
	}




	@Override
	public int compareTo(Ville o) {
		// TODO Auto-generated method stub
		return 0;
	}


	
	
}
