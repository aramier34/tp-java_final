package fr.diginamic.banque1;


public class ConversionNombre {

	public static void main(String[] args) {
		String chaine = "12";
		int a = Integer.parseInt(chaine);
		int b = 15;
		System.out.println("Le max de a et b est : "+Integer.max(a, b));
		
		
	}

}
