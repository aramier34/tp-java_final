package fr.diginamic.fichier;

public class Ville {

	String nom;
	int codeDepartement;
	String nomRegion;
	int popTotale;
	
	
}
