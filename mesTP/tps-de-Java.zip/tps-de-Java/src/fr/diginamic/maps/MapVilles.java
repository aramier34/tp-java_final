package fr.diginamic.maps;

import fr.diginamic.tri.Ville;

public class MapVilles {

	public static void main(String[] args) {


		
		
	}

}
