package entites2;

public class TestAdressePostale1 {

	public static void main(String[] args) {
		AdressePostale1 adressePostale = new AdressePostale1(41,"rue du genou","34000","Montpellier");
		AdressePostale1 adressePostale2 = new AdressePostale1(3,"ruelle courte","33000","Bordeaux");
	}

}
