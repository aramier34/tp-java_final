package entites2;

public class Constantes1 {
	static final int NB_DEPARTEMENTS = 100;
	static final int NB_REGIONS = 18;

}
