package entities;

public class TestAdressePostale {

	public static void main(String[] args) {

		AdressePostale adresse1 = new AdressePostale(4, "rue de labeur", "54700", "paris");
		AdressePostale adresse2 = new AdressePostale(12, "rue du paradis", "98552", "toul");

	}

}
