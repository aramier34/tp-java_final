package entities;

public class Operation {

	
	//pas de variable d'instance donc méthode static recommandé
	
	public static int addition (int a, int b) {
		int c =a +b;
		return c;
	}
}
