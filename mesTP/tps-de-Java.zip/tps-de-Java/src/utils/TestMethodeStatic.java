package utils;

public class TestMethodeStatic {
	
	public static String chaine = "12";
	
	public static void main(String[] args) {
	
		
	int a =Integer.parseInt(chaine);
	System.out.println(a);
	
	int b = 15;
	int c=20;
	
	int maxi=Integer.max(c, b);
	System.out.println(maxi);

	
	
	

	}
}
